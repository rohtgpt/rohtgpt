from pyspark.sql import SparkSession

master = 'local'
appName = 'SparkSQLApp'

spark = SparkSession.builder.appName(appName).getOrCreate()

jdbcURL = 'jdbc:mysql://localhost/ER_Project'
user = 'root'
password = 'Rohit123@'

# Read the complete table
dfFromDb = spark.read.format('jdbc') \
    .option('url', jdbcURL) \
    .option('user', user) \
    .option('password', password) \
    .option('dbtable', 'Amazon_data') \
    .load()
dfFromDb.printSchema()
dfFromDb.show()

dfFromDb.createGlobalTempView('Amazon_data')

df1 = spark.sql('select id,title,description,manufacturer,price from global_temp.Amazon_data order by id')
df1.show()
print("done")

df1.write.option('header',True).csv("hdfs://localhost:9000/ER_Project/stage/Amazon_Google_Examples/Amazon_data",header = True ,mode = 'overwrite')
print("File written successfully on HDFS .")


# df2=spark.read.option('header',True).csv("hdfs://localhost:9000/ER_Project/stage/Amazon_Google_Examples/Amazon_data")
# df2.show()