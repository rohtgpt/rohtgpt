# create dir stage in /ER_Project/stage
hdfs dfs -mkdir /ER_Project
hdfs dfs -mkdir /ER_Project/stage
hdfs dfs -mkdir /ER_Project/stage/ground_truth

hdfs dfs -put /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/ground_truth_sample.csv /ER_Project/stage/ground_truth

#ingest data to MYSQL
mysql --local-infile=1 -h localhost -u root --password=Rohit123@ -D ER_Project -e 'source /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/SQL_cmd_for_StructData/SQL_cmd.sql'
# MYSQL DB  to HDFS (csv)
spark-submit --master local /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/1_SparkSQL.py


#ingest data to Cassandra
cqlsh -u 'cassandra' -p 'cassandra' -f /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/SQL_cmd_for_StructData/CQL_command.cql
# Cassandra to HDFS
spark-submit --packages com.datastax.spark:spark-cassandra-connector_2.12:3.1.0 --master local /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/3_SparkCassandra.py


#ingest(json) data into MONGODB
#mongoimport --uri mongodb+srv://cdec:cdec@cluster0.brmwu.mongodb.net/ER_Project --collection Sample --type csv --headerline --file /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Sample2_cleaned.csv
mongoimport --uri mongodb+srv://cdec:cdec@cluster0.brmwu.mongodb.net/ER_Project --collection dataset1 --type json --file /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/data/final_part_01.json
mongoimport --uri mongodb+srv://cdec:cdec@cluster0.brmwu.mongodb.net/ER_Project --collection dataset2 --type json --file /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/data/final_part_02.json
mongoimport --uri mongodb+srv://cdec:cdec@cluster0.brmwu.mongodb.net/ER_Project --collection dataset3 --type json --file /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/data/final_part_03.json
mongoimport --uri mongodb+srv://cdec:cdec@cluster0.brmwu.mongodb.net/ER_Project --collection dataset4 --type json --file /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/data/Final_Part_04.json
mongoimport --uri mongodb+srv://cdec:cdec@cluster0.brmwu.mongodb.net/ER_Project --collection dataset5 --type json --file /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/data/final_part_05.json
#MONGODB to HDFS (json)
#spark-submit --packages org.mongodb.spark:mongo-spark-connector_2.12:3.0.0 --master local /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/2_SparkMongo.py
spark-submit --packages org.mongodb.spark:mongo-spark-connector_2.12:3.0.0 --master local /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Data_Loading/1_Dataset.py
spark-submit --packages org.mongodb.spark:mongo-spark-connector_2.12:3.0.0 --master local /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Data_Loading/2_Dataset.py
spark-submit --packages org.mongodb.spark:mongo-spark-connector_2.12:3.0.0 --master local /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Data_Loading/3_Dataset.py
spark-submit --packages org.mongodb.spark:mongo-spark-connector_2.12:3.0.0 --master local /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Data_Loading/4_dataset.py
spark-submit --packages org.mongodb.spark:mongo-spark-connector_2.12:3.0.0 --master local /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Data_Loading/5_dataset.py

#Spark-ER stage on main data
#spark-submit --py-files /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/ER_LIbrary/file.zip --master local /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/main.py

#Spark-ER stage on Sample data
spark-submit --py-files /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/ER_LIbrary/file.zip --master local /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/main_sample.py