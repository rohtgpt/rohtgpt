#!/usr/bin/env python
# coding: utf-8

# # Dirty Dataset
# This example illustrate how to perform meta-blocking on a dirty dataset (data deduplication), so when we have one dataset that contains duplicates.

# In[18]:


# import sparker
# import random

from wrappers import CSVWrapper
from blockers import Blocking
from blocking_strategies import BlockingKeysStrategies
from filters import BlockPurging
from filters import BlockFiltering
from converters import Converters
from utils import Utils
from wnp import WNP
from pruning_utils import WeightTypes,ComparisonTypes
import random
from pyspark import SparkContext
import pandas as pd
import numpy as np


# profiles1 = CSVWrapper.load_profiles('Sample1_cleaned.csv',separator=",", header=True,
#                                              real_id_field = "id",
#                                             source_id = 0)


# Profiles contained in the first dataset
profiles = CSVWrapper.load_profiles('Sales.csv', real_id_field = "Order_id")


# Let's visualize a profile to check if they are correctly loaded

# In[3]:


print(profiles.take(1)[0])


# Extract the max id (it will be used later)

# In[4]:


# Max profile id
max_profile_id = profiles.map(lambda profile: profile.profile_id).max()


# In[5]:


max_profile_id


# ### Groundtruth (optional)
# If you have a groundtruth you can measure the performance of each step.
# 
# When you load the groundtruth it contains the original profiles IDs, it is necessary to convert it to use the IDs assigned to each profile by Spark.

# In[5]:


# Loads the groundtruth, takes as input the path of the file and the names of the attributes that represent
# respectively the id of profiles of the first dataset and the id of profiles of the second dataset
#gt = sparker.CSVWrapper.load_groundtruth('../datasets/dirty/cora/groundtruth.csv', 'id1', 'id2')


# In[6]:


# Converts the groundtruth by replacing original IDs with those given by Spark
#new_gt = sparker.Converters.convert_groundtruth(gt, profiles)


# In[7]:


# We can explore some pairs
#random.sample(new_gt, 2)


# ## Blocking
# Now we can perform blocking.
# 
# By default sparkER performs token blocking, but it is possible to provide a different blocking function.
# 
# In the following example each token is splitted in ngrams of size 4 that are used for blocking.

# In[6]:


# blocks = sparker.Blocking.create_blocks(profiles,
#                                         blocking_method=sparker.BlockingKeysStrategies.ngrams_blocking,
#                                         ngram_size=4)
# print("Number of blocks",blocks.count())


# Let's continue by using the standard token blocking

# In[7]:


blocks = Blocking.create_blocks(profiles)
print("Number of blocks",blocks.count())


# ## Block cleaning
# 
# sparkER implements two block cleaning strategies:
# 
# * Block purging: discard the largest blocks that involve too many comparisons, the parameter must be >= 1. A lower value mean a more aggressive purging.
# * Block cleaning: removes for every profile the largest blocks in which it appears. The parameter is in range ]0, 1\[. A lower value mean a more aggressive cleaning.

# In[8]:


# Perfoms the purging
blocks_purged = BlockPurging.block_purging(blocks, 1.025)


# In[9]:


# Performs the cleaning
(profile_blocks, profile_blocks_filtered, blocks_after_filtering) = BlockFiltering.block_filtering_quick(blocks_purged, 0.8)


# If you have the groundtruth, after every blocking step it is possible to check which are the performance of the blocking collection.

# In[9]:


# recall, precision, cmp_n = sparker.Utils.get_statistics(blocks_after_filtering, max_profile_id, new_gt)
#
# print("Recall", recall)
# print("Precision", precision)
# print("Number of comparisons", cmp_n)


# ## Meta-blocking
# Meta-blocking can be used to further refine the block collection removing superfluous comparisons.
# 
# SparkER implements different kind of meta-blocking algorithms, you can find the descriptions in our paper.
# 
# 
# For every partition of the RDD the pruning algorithm returns as output a triplet that contains:
# 
# * The number of edges
# * The number of matches (only if the groundtruth is provided)
# * The retained edges
# 
# To perform the meta-blocking first some data structures have to be created.

# In[10]:


from pyspark import SparkContext
sc = SparkContext.getOrCreate()


# In[11]:


block_index_map = blocks_after_filtering.map(lambda b : (b.block_id, b.profiles)).collectAsMap()
block_index = sc.broadcast(block_index_map)

# This is only needed for certain weight measures
profile_blocks_size_index = sc.broadcast(profile_blocks_filtered.map(lambda pb : (pb.profile_id, len(pb.blocks))).collectAsMap())

# Broadcasted groundtruth
# gt_broadcast = sc.broadcast(new_gt)


# ### Weighted Node Pruning

# In[12]:


results = WNP.wnp(
                          profile_blocks_filtered,
                          block_index,
                          max_profile_id,
                          weight_type=WeightTypes.CBS,
                          # groundtruth=gt_broadcast,
                          profile_blocks_size_index=profile_blocks_size_index,
                          comparison_type=ComparisonTypes.OR
                         )
num_edges = results.map(lambda x: x[0]).sum()
num_matches = results.map(lambda x: x[1]).sum()
# print("Recall", num_matches/len(new_gt))
# print("Precision", num_matches/num_edges)
print("Number of comparisons",num_edges)


# ### Reciprocal Weighted Node Pruning

# In[13]:


# results = WNP.wnp(
#                           profile_blocks_filtered,
#                           block_index,
#                           max_profile_id,
#                           weight_type=sparker.WeightTypes.CBS,
#                           #groundtruth=gt_broadcast,
#                           profile_blocks_size_index=profile_blocks_size_index,
#                           comparison_type=sparker.ComparisonTypes.AND
#                          )
# num_edges = results.map(lambda x: x[0]).sum()
# num_matches = results.map(lambda x: x[1]).sum()
# # print("Recall", num_matches/len(new_gt))
# # print("Precision", num_matches/num_edges)
# print("Number of comparisons",num_edges)


# ### Weighted Edge Pruning

# In[16]:


# results = sparker.WEP.wep(
#                           profile_blocks_filtered,
#                           block_index,
#                           max_profile_id,
#                           weight_type=sparker.WeightTypes.CBS,
#                           groundtruth=gt_broadcast,
#                           profile_blocks_size_index=profile_blocks_size_index
#                          )
# num_edges = results.map(lambda x: x[0]).sum()
# num_matches = results.map(lambda x: x[1]).sum()
# print("Recall", num_matches/len(new_gt))
# print("Precision", num_matches/num_edges)
# print("Number of comparisons",num_edges)
#
#
# # ### Cardinality Node Pruning
#
# # In[17]:
#
#
# results = sparker.CNP.cnp(
#                           blocks_after_filtering,
#                           profiles.count(),
#                           profile_blocks_filtered,
#                           block_index,
#                           max_profile_id,
#                           weight_type=sparker.WeightTypes.CBS,
#                           groundtruth=gt_broadcast,
#                           profile_blocks_size_index=profile_blocks_size_index,
#                           comparison_type=sparker.ComparisonTypes.OR
#                          )
# num_edges = results.map(lambda x: x[0]).sum()
# num_matches = results.map(lambda x: x[1]).sum()
# print("Recall", num_matches/len(new_gt))
# print("Precision", num_matches/num_edges)
# print("Number of comparisons",num_edges)
#
#
# # ### Reciprocal Cardinality Node Pruning
#
# # In[18]:
#
#
# results = sparker.CNP.cnp(
#                           blocks_after_filtering,
#                           profiles.count(),
#                           profile_blocks_filtered,
#                           block_index,
#                           max_profile_id,
#                           weight_type=sparker.WeightTypes.CBS,
#                           groundtruth=gt_broadcast,
#                           profile_blocks_size_index=profile_blocks_size_index,
#                           comparison_type=sparker.ComparisonTypes.AND
#                          )
# num_edges = results.map(lambda x: x[0]).sum()
# num_matches = results.map(lambda x: x[1]).sum()
# print("Recall", num_matches/len(new_gt))
# print("Precision", num_matches/num_edges)
# print("Number of comparisons",num_edges)
#
#
# # ### Cardinality Edge Pruning
#
# # In[19]:
#
#
# results = sparker.CEP.cep(
#                           profile_blocks_filtered,
#                           block_index,
#                           max_profile_id,
#                           weight_type=sparker.WeightTypes.CBS,
#                           groundtruth=gt_broadcast,
#                           profile_blocks_size_index=profile_blocks_size_index
#                          )
# num_edges = results.map(lambda x: x[0]).sum()
# num_matches = results.map(lambda x: x[1]).sum()
# print("Recall", num_matches/len(new_gt))
# print("Precision", num_matches/num_edges)
# print("Number of comparisons",num_edges)


# ## Collecting edges after meta-blocking
# As mentioned before, the third element of the tuples returned by the meta-blocking contains the edges.
# 
# 
# Edges are weighted according to the weight strategy provided to the meta-blocking.

# In[20]:


edges = results.flatMap(lambda x: x[2])

edges.take(10)


max_by_group = (edges
  .map(lambda x: (x[0], x))
   .reduceByKey(lambda x1, x2: max(x1, x2, key=lambda x: x[-1]))
   .values())

max_by_group.take(60)

dataCollect = max_by_group.collect()
df =  pd.DataFrame(dataCollect)
df


# In[ ]:




