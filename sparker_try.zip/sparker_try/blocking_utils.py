class BlockingUtils(object):
    @staticmethod
    def separate_profiles(elements, separators):
        input_e = elements
        output = []
        for sep in separators:
            a = [x for x in input_e if x <= sep]
            input_e = [x for x in input_e if x > sep]
            output.append(a)
        output.append(input_e)
        a1 = list(map(lambda x: set(x), output))
        # for i in a1:
        #     print(a1)
        return list(map(lambda x: set(x), output))