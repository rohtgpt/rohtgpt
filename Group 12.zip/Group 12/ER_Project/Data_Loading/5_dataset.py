from pyspark.sql import SparkSession

spark = SparkSession.\
builder.\
appName("SparkMongoDBApp").\
master("local").\
config("spark.mongodb.input.uri", "mongodb+srv://cdec:cdec@cluster0.brmwu.mongodb.net/ER_Project.dataset5?retryWrites=true&w=majority").\
config("spark.mongodb.output.uri", "mongodb+srv://cdec:cdec@cluster0.brmwu.mongodb.net/ER_Project.dataset5?retryWrites=true&w=majority").\
config("spark.jars.packages", "org.mongodb.spark:mongo-spark-connector_2.12:3.0.0").\
getOrCreate()

df = spark.read.format("mongo").load()

df.printSchema()
df.show()
df.createGlobalTempView('dataset5')

#
df1 = spark.sql('select id,DisplayName,Location,Birthdate,PhoneNumber,City,State,Country from global_temp.dataset5 order by id')
df1.show()
print("done")

df1.write.json("hdfs://localhost:9000/ER_Project/stage/ER_dataset2" ,mode = 'append')
print("File written successfully on HDFS")

# df2=spark.read.option('header',True).json("hdfs://localhost:9000/ER_Project/stage/ER_dataset2")
# df2.show()