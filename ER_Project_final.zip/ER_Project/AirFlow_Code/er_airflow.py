from airflow.models import DAG
from airflow.operators.bash import BashOperator

from airflow.utils.dates import days_ago

args = {
    'owner':'Project_Team'
}

dag = DAG(
    dag_id='ER_Project',
    default_args=args,
    start_date=days_ago(1),
    schedule_interval=None,
    params={},
    tags=['edbda', 'spark', 'spark-submit']
)

bashOp1 = BashOperator(
    task_id='project_commands',
    start_date=days_ago(1),
    bash_command='scripts/er_command.sh',
    params=None,
    default_args={},
    dag=dag
)

bashOp2 = BashOperator(
    task_id='project_Amzon_Google_commands',
    start_date=days_ago(1),
    bash_command='scripts/Amazon_Google_er_command.sh',
    params=None,
    default_args={},
    dag=dag
)

taskStart = BashOperator(task_id="TaskStart",
                       bash_command="echo start_project",
                       cwd="/tmp",
                       dag=dag)

taskEnd = BashOperator(task_id="TaskEnd",
                       bash_command="echo end_project",
                       cwd="/tmp",
                       dag=dag)

taskStart >> bashOp1 >> bashOp2 >> taskEnd