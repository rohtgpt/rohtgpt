set global local_infile=true;
CREATE TABLE Amazon_data(
    Id MEDIUMTEXT,
    title MEDIUMTEXT,
    description MEDIUMTEXT,
    manufacturer MEDIUMTEXT,
    price varchar(255)
);
LOAD DATA LOCAL INFILE '/home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Amazon_Google_dataset_Examples/Amazon.csv' INTO TABLE Amazon_data
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;