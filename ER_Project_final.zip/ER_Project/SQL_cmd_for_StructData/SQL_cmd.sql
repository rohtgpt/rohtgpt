set global local_infile=true;
CREATE TABLE Sample(
    Id int,
    DisplayName varchar(255),
    Location varchar(255),
    AboutMe MEDIUMTEXT,
    Age int,
    phone varchar(255),
    City varchar(255),
    State varchar(255),
    Country varchar(255)
);
LOAD DATA LOCAL INFILE '/home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Sample1_cleaned.csv' INTO TABLE Sample
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;