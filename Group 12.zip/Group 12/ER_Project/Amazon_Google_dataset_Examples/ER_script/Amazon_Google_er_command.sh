# create dir stage in /ER_Project/stage

hdfs dfs -mkdir /ER_Project/stage/Amazon_Google_Examples
hdfs dfs -mkdir /ER_Project/stage/Amazon_Google_Examples/ground_truth

hdfs dfs -put /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Amazon_Google_dataset_Examples/Amzon_GoogleProducts_perfectMapping.csv /ER_Project/stage/Amazon_Google_Examples/ground_truth

#ingest data to MYSQL
mysql --local-infile=1 -h localhost -u root --password=Rohit123@ -D ER_Project -e 'source /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Amazon_Google_dataset_Examples/SQL_cmd_for_StructData/sql_command.sql'
# MYSQL DB  to HDFS (csv)
spark-submit --master local /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Amazon_Google_dataset_Examples/DataLoading/1_SparkSQL.py


#ingest data to Cassandra
cqlsh -u 'cassandra' -p 'cassandra' -f /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Amazon_Google_dataset_Examples/SQL_cmd_for_StructData/CQL_command.cql
# Cassandra to HDFS
spark-submit --packages com.datastax.spark:spark-cassandra-connector_2.12:3.1.0 --master local /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Amazon_Google_dataset_Examples/DataLoading/2_SparkCassandra.py


#Spark-ER stage
spark-submit --py-files /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/ER_LIbrary/file.zip --master local /home/rohit/DBDA_HOME/MyHome/spark/ProjectPython/ER_Project/Amazon_Google_dataset_Examples/main_amazon.py