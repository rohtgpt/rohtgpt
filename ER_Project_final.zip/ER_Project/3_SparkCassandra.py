
from pyspark import SparkContext, SparkConf
from pyspark.sql import SQLContext, SparkSession

spark = SparkSession.builder \
  .appName('SparkCassandraApp') \
  .master('local') \
  .config("spark.jars.packages", "com.datastax.spark:spark-cassandra-connector_2.12:3.1.0")\
  .config('spark.cassandra.connection.host', '127.0.0.1') \
  .config('spark.cassandra.connection.port', '9042') \
  .config('spark.cassandra.auth.username','cassandra') \
  .config('spark.cassandra.auth.password','cassandra') \
  .config('spark.cassandra.output.consistency.level','ONE') \
  .getOrCreate()


df = spark.read\
  .format('org.apache.spark.sql.cassandra') \
  .options(table='sample2',keyspace="er_project").load()
df.printSchema()
df.show(10)
df.createGlobalTempView('Sample')

df1 = spark.sql('select id,DisplayName,Location,AboutMe,Age,phone,City,State,Country from global_temp.Sample order by id')
df1.show()
print("done")

df1.write.option('header',True).csv("hdfs://localhost:9000/ER_Project/stage/dataset2" ,mode = 'overwrite')
print("File written successfully on HDFS ")

# df2=spark.read.option('header',True).csv("hdfs://localhost:9000/ER_Project/stage/dataset2")
# df2.show()