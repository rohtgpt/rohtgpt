from wrappers import CSVWrapper
from blockers import Blocking
from blocking_strategies import BlockingKeysStrategies
from filters import BlockPurging
from filters import BlockFiltering
from converters import Converters
from utils import Utils
import pandas as pd
from tabulate import tabulate

''' 
    ALL the meta blocking algorithms
    WNP - Weighted Node Pruning
    RWNP - Reciprocal Node Pruning
    WEP - Weighted Edge Pruning
    CNP - Cardinality Node Pruning
    RCNP - Reciprocal Cardinality Node Pruning
    CEP - Cardinatity Edge Pruning
    
    '''
from wnp import WNP
from wep import WEP
from cnp import CNP
from cep import CEP
from pruning_utils import WeightTypes,ComparisonTypes
import random
from pyspark import SparkContext



profiles1 = CSVWrapper.load_profiles(file_path = 'Sample1_cleaned.csv',
                                             start_id_from = 0,
                                             separator=",", header=True,
                                             real_id_field = "id",
                                            source_id = 0)

separator_id = profiles1.map(lambda profile: profile.profile_id).max()

separator_ids = [separator_id]

print("Source1 Maximum separator Id",separator_ids)
print("Source1 2 profiles",profiles1.take(2),end='\n')

profiles2 = CSVWrapper.load_profiles('Sample2_cleaned.csv',
                                              start_id_from = separator_id+1,
                                              real_id_field = "id",
                                            source_id = 1)
# Max profile id
max_profile_id = profiles2.map(lambda profile: profile.profile_id).max()

print("Source 2 MaxProfileId",max_profile_id)
print("Source 2 profiles:2",profiles2.take(2))

#Union of two profiles from source1 and source2
profiles = profiles1.union(profiles2)
print("\n\n\nCombination of two Profiles",profiles.take(10))

maximum_profile_id_after_union = profiles.map(lambda profile:profile.profile_id).max()
print("maximum_profile_id_after_union",maximum_profile_id_after_union)

#Loading Ground Truth into profiles

gt = CSVWrapper.load_groundtruth('ground_truth_sample.csv', 'id1', 'id2')

print(gt.toDF().show(1400))

new_gt = Converters.convert_groundtruth(gt, profiles1, profiles2)


random.sample(new_gt,5)



# Creating blocks of profile using BlockingKeysStrategies=ngrams_blocking
blocks = Blocking.create_blocks(profiles, separator_ids,
                                        blocking_method=BlockingKeysStrategies.ngrams_blocking,
                                        ngram_size=4)
print("Number of blocks",blocks.count())

print(blocks.take(5))





#Creating blocking of profile using Simple Token Blocking

blocks = Blocking.create_blocks(profiles, separator_ids)
print("Number of blocks",blocks.count())


#Block Cleaning

blocks_purged = BlockPurging.block_purging(blocks, 1.025)

(profile_blocks, profile_blocks_filtered, blocks_after_filtering) = BlockFiltering.block_filtering_quick(blocks_purged, 0.8, separator_ids)

print(profile_blocks.count())
print(profile_blocks_filtered.count())
print(blocks_after_filtering.count())



#Calculate Recall,Precision,cmp_n
recall, precision, cmp_n = Utils.get_statistics(blocks_after_filtering, max_profile_id,new_gt,separator_ids)

print("Recall", recall)
print("Precision", precision)
print("Number of comparisons", cmp_n)


###Meta Blocking

'''
Meta-blocking can be used to further refine the block collection removing superfluous comparisons.

SparkER implements different kind of meta-blocking algorithms, you can find the descriptions in our paper.

For every partition of the RDD the pruning algorithm returns as output a triplet that contains:

    # The number of edges
    # The number of matches (only if the groundtruth is provided)
    # The retained edges

To perform the meta-blocking first some data structures have to be created.


'''

sc = SparkContext.getOrCreate()

block_index_map = blocks_after_filtering.map(lambda b : (b.block_id, b.profiles)).collectAsMap()
block_index = sc.broadcast(block_index_map)

# This is only needed for certain weight measures
profile_blocks_size_index = sc.broadcast(profile_blocks_filtered.map(lambda pb : (pb.profile_id, len(pb.blocks))).collectAsMap())

# Broadcasted groundtruth
gt_broadcast = sc.broadcast(new_gt)


# Weighted Node Pruning Algorithm

print("\n\n\n\n\n Weighted Node Pruning")
WNP_results = WNP.wnp(
                          profile_blocks_filtered,
                          block_index,
                          max_profile_id,
                          separator_ids,
                          weight_type=WeightTypes.CBS,
                          groundtruth=gt_broadcast,
                          profile_blocks_size_index=profile_blocks_size_index,
                          comparison_type=ComparisonTypes.OR
                         )

num_edges = WNP_results.map(lambda x: x[0]).sum()
num_matches = WNP_results.map(lambda x: x[1]).sum()
recall = num_matches/len(new_gt)
precision = (num_matches/num_edges)
print("Recall", recall)
print("Precision", precision)
print("Number of comparisons",num_edges)
wnp_f1 = 2*((precision*recall)/(precision+recall))
print("F1 score",wnp_f1)

print("Number of entity resolved",num_matches)

'''newColumns = ["no_of_edges","no_of_matches","retaind_edges"]
WNP_results.toDF(newColumns).show()'''


#Reciprocal Weighted Node Pruning


print("\n\n\n\n\n Reciprocal Weighted Node Pruning")

RWNP_results = WNP.wnp(
                          profile_blocks_filtered,
                          block_index,
                          max_profile_id,
                          separator_ids,
                          weight_type=WeightTypes.CBS,
                          groundtruth=gt_broadcast,
                          profile_blocks_size_index=profile_blocks_size_index,
                          comparison_type=ComparisonTypes.AND
                         )
num_edges = RWNP_results.map(lambda x: x[0]).sum()
num_matches = RWNP_results.map(lambda x: x[1]).sum()

recall = num_matches/len(new_gt)
precision = (num_matches/num_edges)
print("Recall", recall)
print("Precision", precision)
print("Number of comparisons",num_edges)
rwnp_f1 = 2*((precision*recall)/(precision+recall))
print("F1 score",rwnp_f1)


'''newColumns = ["no_of_edges","no_of_matches","retaind_edges"]
RWNP_results.toDF(newColumns).show()'''



print("\n\n\n\n\n Weighted Edge Pruning")

WEP_results = WEP.wep(
                          profile_blocks_filtered,
                          block_index,
                          max_profile_id,
                          separator_ids,
                          weight_type=WeightTypes.CBS,
                          groundtruth=gt_broadcast,
                          profile_blocks_size_index=profile_blocks_size_index
                         )
num_edges = WEP_results.map(lambda x: x[0]).sum()
num_matches = WEP_results.map(lambda x: x[1]).sum()

recall = num_matches/len(new_gt)
precision = (num_matches/num_edges)
print("Recall", recall)
print("Precision", precision)
print("Number of comparisons",num_edges)
wep_f1 = 2*((precision*recall)/(precision+recall))
print("F1 score",wep_f1)


'''newColumns = ["no_of_edges","no_of_matches","retaind_edges"]
WEP_results.toDF(newColumns).show()'''



print("\n\n\n\n\n Cardinality Node Pruning")

CNP_results = CNP.cnp(
                          blocks_after_filtering,
                          profiles.count(),
                          profile_blocks_filtered,
                          block_index,
                          max_profile_id,
                          separator_ids,
                          weight_type=WeightTypes.CBS,
                          groundtruth=gt_broadcast,
                          profile_blocks_size_index=profile_blocks_size_index,
                          comparison_type=ComparisonTypes.OR
                         )
num_edges = CNP_results.map(lambda x: x[0]).sum()
num_matches = CNP_results.map(lambda x: x[1]).sum()

recall = num_matches/len(new_gt)
precision = (num_matches/num_edges)
print("Recall", recall)
print("Precision", precision)
print("Number of comparisons",num_edges)
cnp_f1 = 2*((precision*recall)/(precision+recall))
print("F1 score",cnp_f1)

'''
newColumns = ["no_of_edges","no_of_matches","retaind_edges"]
CNP_results.toDF(newColumns).show()'''


print("\n\n\n\n\n Reciprocal Cardinality Node Pruning")

RCNP_results = CNP.cnp(
                          blocks_after_filtering,
                          profiles.count(),
                          profile_blocks_filtered,
                          block_index,
                          max_profile_id,
                          separator_ids,
                          weight_type=WeightTypes.CBS,
                          groundtruth=gt_broadcast,
                          profile_blocks_size_index=profile_blocks_size_index,
                          comparison_type=ComparisonTypes.AND
                         )
num_edges = RCNP_results.map(lambda x: x[0]).sum()
num_matches = RCNP_results.map(lambda x: x[1]).sum()

recall = num_matches/len(new_gt)
precision = (num_matches/num_edges)
print("Recall", recall)
print("Precision", precision)
print("Number of comparisons",num_edges)
rcnp_f1 = 2*((precision*recall)/(precision+recall))
print("F1 score",rcnp_f1)

'''
newColumns = ["no_of_edges","no_of_matches","retaind_edges"]
RCNP_results.toDF(newColumns).show()'''


print("\n\n\n\n\n Cardinality Edge Pruning")

CEP_results = CEP.cep(
                          profile_blocks_filtered,
                          block_index,
                          max_profile_id,
                          separator_ids,
                          weight_type=WeightTypes.CBS,
                          groundtruth=gt_broadcast,
                          profile_blocks_size_index=profile_blocks_size_index
                         )
num_edges = CEP_results.map(lambda x: x[0]).sum()
num_matches = CEP_results.map(lambda x: x[1]).sum()

recall = num_matches/len(new_gt)
precision = (num_matches/num_edges)
print("Recall", recall)
print("Precision", precision)
print("Number of comparisons",num_edges)
cep_f1 = 2*((precision*recall)/(precision+recall))
print("F1 score",cep_f1)



'''
Collecting edges after meta-blocking

As mentioned before, the third element of the tuples returned by the meta-blocking contains the edges.

Edges are weighted according to the weight strategy provided to the meta-blocking.

'''

f1_score_list = [wnp_f1,rwnp_f1,wep_f1,cnp_f1,rcnp_f1,cep_f1]
f1_score_final = max(f1_score_list)


print("\n\n\n F1_score_final",f1_score_final)

if(f1_score_final == wnp_f1):
    final_score_result = WNP_results
elif(f1_score_final == rwnp_f1):
    final_score_result = RWNP_results
elif(f1_score_final == wep_f1):
    final_score_result = WEP_results
elif(f1_score_final == cnp_f1):
    final_score_result = CNP_results
elif(f1_score_final == rcnp_f1):
    final_score_result = RCNP_results
elif(f1_score_final == cep_f1):
    final_score_result = CEP_results


edges = final_score_result.flatMap(lambda x: x[2])

print(edges.count())

newColumns = ["profile_id","neighbor_id","neighbor_weight"]
ans = edges.toDF(newColumns)

print(ans)

max_by_group = (edges
  .map(lambda x: (x[0], x))
   .reduceByKey(lambda x1, x2: max(x1, x2, key=lambda x: x[-1]))
   .values())

dataCollect = max_by_group.collect()
df =  pd.DataFrame(dataCollect)
print(df)

df.rename(columns = {0:'P_id', 1:'N_id',
                              2:'weight'}, inplace = True)

n = df.filter(["P_id","N_id","weight"])
n = pd.DataFrame(n)


n["N_id"] = n["N_id"]-(separator_id+1)
new_df = n[(n['weight']>6)]


df1 = pd.read_csv("Sample1_cleaned.csv")
df2 = pd.read_csv("Sample2_cleaned.csv")

df1["new_id"] = [x for x in range(0,len(df1))]
df2["new_id"] = [x for x in range(0,len(df2))]


lst_col = []
lst = df2.columns
for i in lst:
    lst_col.append(i+"_2")


df2.columns = lst_col


# inner join on two dataframes
common_df = df1.merge(new_df,how='inner', left_on='new_id', right_on='P_id')
common_df_2 = common_df.merge(df2,how='inner', left_on='N_id', right_on='new_id_2')
common_df_2 = common_df_2.drop(["P_id", "N_id"], axis=1)
print(tabulate(common_df_2, tablefmt = 'psql'))

#common_df_2.to_csv('/home/aditi/BigData/AAI_Project/dataset/Output.csv', header=True, index=False)
