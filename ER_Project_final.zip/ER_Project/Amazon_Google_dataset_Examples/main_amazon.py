import pandas as pd

from pyspark.sql import SparkSession

from blockers import Blocking
from blocking_strategies import BlockingKeysStrategies
from converters import Converters
from filters import BlockFiltering
from filters import BlockPurging
from utils import Utils
# from wrappers import CSVWrapper
# from wrappers import JSONWrapper
import wrappers as wrappers

''' 
    ALL the meta blocking algorithms
    WNP - Weighted Node Pruning
    RWNP - Reciprocal Node Pruning
    WEP - Weighted Edge Pruning
    CNP - Cardinality Node Pruning
    RCNP - Reciprocal Cardinality Node Pruning
    CEP - Cardinatity Edge Pruning
    
    '''
from wnp import WNP
from wep import WEP
from cep import CEP
from pruning_utils import WeightTypes,ComparisonTypes
import random

from pyspark import SparkContext
sc = SparkContext.getOrCreate()

spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()
ss = SparkSession(sc)


#################################################

# get column id
df1 = ss.read.option("header",True)\
        .option("inferSchema",True)\
        .csv('hdfs://localhost:9000/ER_Project/stage/Amazon_Google_Examples/Amazon_data')



df2 = ss.read.option("header",True)\
        .option("inferSchema",True)\
        .csv('hdfs://localhost:9000/ER_Project/stage/Amazon_Google_Examples/Google_data')


df_gt = ss.read.option("header",True)\
        .option("inferSchema",True)\
        .csv('hdfs://localhost:9000/ER_Project/stage/Amazon_Google_Examples/ground_truth')



col_df1 =  df1.columns
col_df2 =  df2.columns
col_g1 = df_gt.columns

id_1 = col_df1[0]
id_2 = col_df2[0]
id_g_1 = col_g1[0]
id_g_2 = col_g1[1]

print(id_2)

##################################################

profiles1 = wrappers.CSVWrapper.load_profiles('hdfs://localhost:9000/ER_Project/stage/Amazon_Google_Examples/Amazon_data',
                                         start_id_from=0,
                                         separator=",", header=True,
                                         real_id_field=id_1,
                                         source_id=0)

separator_id = profiles1.map(lambda profile: profile.profile_id).max()

separator_ids = [separator_id]

print("Source1 Maximum separator Id", separator_ids)
print("Source1 2 profiles", profiles1.take(2), end='\n')

#########################################################################
profiles2 = wrappers.CSVWrapper.load_profiles(file_path = 'hdfs://localhost:9000/ER_Project/stage/Amazon_Google_Examples/Google_data',
                                              start_id_from = separator_id+1,
                                              real_id_field = id_2,
                                              source_id = 1)
# Max profile id
max_profile_id = profiles2.map(lambda profile: profile.profile_id).max()

print("Source 2 MaxProfileId",max_profile_id)
print("Source 2 profiles:2")
print(profiles2.toDF().show(3))

#Union of two profiles from source1 and source2
profiles = profiles1.union(profiles2)
print(profiles.toDF().show(13))

print("\n\n\nCombination of two Profiles",profiles.take(10))

maximum_profile_id_after_union = profiles.map(lambda profile:profile.profile_id).max()
print("maximum_profile_id_after_union",maximum_profile_id_after_union)

#Loading Ground Truth into profiles

# Loads the groundtruth, takes as input the path of the file and the names of the attributes that represent
# respectively the id of profiles of the first dataset and the id of profiles of the second dataset
gt = wrappers.CSVWrapper.load_groundtruth('hdfs://localhost:9000/ER_Project/stage/Amazon_Google_Examples/ground_truth',
                                        id_g_1, id_g_2)



new_gt = Converters.convert_groundtruth(gt, profiles1, profiles2)
#print(new_gt)

#print(f"len(gt) = {len(new_gt)}")


#random.sample(new_gt,5)



# Creating blocks of profile using BlockingKeysStrategies=ngrams_blocking
blocks = Blocking.create_blocks(profiles, separator_ids,
                                        blocking_method=BlockingKeysStrategies.ngrams_blocking,
                                        ngram_size=4)
print("Number of blocks",blocks.count())

print(blocks.take(5))





#Creating blocking of profile using Simple Token Blocking

blocks = Blocking.create_blocks(profiles, separator_ids)
print("Number of blocks",blocks.count())


#Block Cleaning

blocks_purged = BlockPurging.block_purging(blocks, 1.025)

(profile_blocks, profile_blocks_filtered, blocks_after_filtering) = BlockFiltering.block_filtering_quick(blocks_purged, 0.8, separator_ids)

print(profile_blocks.count())
print(profile_blocks_filtered.count())
print(blocks_after_filtering.count())



#Calculate Recall,Precision,cmp_n
recall, precision, cmp_n = Utils.get_statistics(blocks_after_filtering, max_profile_id,new_gt,separator_ids)

print("Recall", recall)
print("Precision", precision)
print("Number of comparisons", cmp_n)


###Meta Blocking

'''
Meta-blocking can be used to further refine the block collection removing superfluous comparisons.

SparkER implements different kind of meta-blocking algorithms, you can find the descriptions in our paper.

For every partition of the RDD the pruning algorithm returns as output a triplet that contains:

    # The number of edges
    # The number of matches (only if the groundtruth is provided)
    # The retained edges

To perform the meta-blocking first some data structures have to be created.


'''

block_index_map = blocks_after_filtering.map(lambda b : (b.block_id, b.profiles)).collectAsMap()
block_index = sc.broadcast(block_index_map)

# This is only needed for certain weight measures
profile_blocks_size_index = sc.broadcast(profile_blocks_filtered.map(lambda pb : (pb.profile_id, len(pb.blocks))).collectAsMap())

# Broadcasted groundtruth
gt_broadcast = sc.broadcast(new_gt)


# Weighted Node Pruning Algorithm

print("\n\n\n\n\n Weighted Node Pruning")
WNP_results = WNP.wnp(
                          profile_blocks_filtered,
                          block_index,
                          max_profile_id,
                          separator_ids,
                          weight_type=WeightTypes.CBS,
                          groundtruth=gt_broadcast,
                          profile_blocks_size_index=profile_blocks_size_index,
                          comparison_type=ComparisonTypes.OR
                         )

num_edges = WNP_results.map(lambda x: x[0]).sum()
num_matches = WNP_results.map(lambda x: x[1]).sum()
recall = num_matches/len(new_gt)
precision = (num_matches/num_edges)
print("Recall", recall)
print("Precision", precision)
print("Number of comparisons",num_edges)
wnp_f1 = 2*((precision*recall)/(precision+recall))
print("F1 score",wnp_f1)

print("Number of entity resolved",num_matches)

'''newColumns = ["no_of_edges","no_of_matches","retaind_edges"]
WNP_results.toDF(newColumns).show()'''


#Reciprocal Weighted Node Pruning


print("\n\n\n\n\n Reciprocal Weighted Node Pruning")

RWNP_results = WNP.wnp(
                          profile_blocks_filtered,
                          block_index,
                          max_profile_id,
                          separator_ids,
                          weight_type=WeightTypes.CBS,
                          groundtruth=gt_broadcast,
                          profile_blocks_size_index=profile_blocks_size_index,
                          comparison_type=ComparisonTypes.AND
                         )
num_edges = RWNP_results.map(lambda x: x[0]).sum()
num_matches = RWNP_results.map(lambda x: x[1]).sum()

recall = num_matches/len(new_gt)
precision = (num_matches/num_edges)
print("Recall", recall)
print("Precision", precision)
print("Number of comparisons",num_edges)
rwnp_f1 = 2*((precision*recall)/(precision+recall))
print("F1 score",rwnp_f1)


'''newColumns = ["no_of_edges","no_of_matches","retaind_edges"]
RWNP_results.toDF(newColumns).show()'''



print("\n\n\n\n\n Weighted Edge Pruning")

WEP_results = WEP.wep(
                          profile_blocks_filtered,
                          block_index,
                          max_profile_id,
                          separator_ids,
                          weight_type=WeightTypes.CBS,
                          groundtruth=gt_broadcast,
                          profile_blocks_size_index=profile_blocks_size_index
                         )
num_edges = WEP_results.map(lambda x: x[0]).sum()
num_matches = WEP_results.map(lambda x: x[1]).sum()

recall = num_matches/len(new_gt)
precision = (num_matches/num_edges)
print("Recall", recall)
print("Precision", precision)
print("Number of comparisons",num_edges)
wep_f1 = 2*((precision*recall)/(precision+recall))
print("F1 score",wep_f1)


'''newColumns = ["no_of_edges","no_of_matches","retaind_edges"]
WEP_results.toDF(newColumns).show()'''


print("\n\n\n\n\n Cardinality Edge Pruning")

CEP_results = CEP.cep(
                          profile_blocks_filtered,
                          block_index,
                          max_profile_id,
                          separator_ids,
                          weight_type=WeightTypes.CBS,
                          groundtruth=gt_broadcast,
                          profile_blocks_size_index=profile_blocks_size_index
                         )
num_edges = CEP_results.map(lambda x: x[0]).sum()
num_matches = CEP_results.map(lambda x: x[1]).sum()

recall = num_matches/len(new_gt)
precision = (num_matches/num_edges)
print("Recall", recall)
print("Precision", precision)
print("Number of comparisons",num_edges)
cep_f1 = 2*((precision*recall)/(precision+recall))
print("F1 score",cep_f1)



'''
Collecting edges after meta-blocking

As mentioned before, the third element of the tuples returned by the meta-blocking contains the edges.

Edges are weighted according to the weight strategy provided to the meta-blocking.

'''

f1_score_list = [wnp_f1,rwnp_f1,wep_f1,cep_f1]
f1_score_final = max(f1_score_list)


print("\n\n\n F1_score_final",f1_score_final)

if(f1_score_final == wnp_f1):
    final_score_result = WNP_results
elif(f1_score_final == rwnp_f1):
    final_score_result = RWNP_results
elif(f1_score_final == wep_f1):
    final_score_result = WEP_results
elif(f1_score_final == cep_f1):
    final_score_result = CEP_results


edges = final_score_result.flatMap(lambda x: x[2])

print(edges.count())

newColumns = ["profile_id","neighbor_id","neighbor_weight"]
ans = edges.toDF(newColumns)

print(ans)

max_by_group = (edges
  .map(lambda x: (x[0], x))
   .reduceByKey(lambda x1, x2: max(x1, x2, key=lambda x: x[-1]))
   .values())

dataCollect = max_by_group.collect()
df =  pd.DataFrame(dataCollect)
print(df)

df.rename(columns = {0:'P_id', 1:'N_id',
                              2:'weight'}, inplace = True)

n = df.filter(["P_id","N_id","weight"])
n = pd.DataFrame(n)

# avg_val = n["weight"].mean()
# avg_val = round(avg_val,0)
# avg_val
#
# n["N_id"] = n["N_id"]-(separator_id+1)
# new_df = n[(n['weight']>avg_val)]

max1 = n["weight"].max()
max1 = round(max1,0)
max1


max_percentage = (max1*30)/100
n["N_id"] = n["N_id"]-(separator_id+1)
new_df = n[(n['weight']>max_percentage)]
new_df

new_df["c_id"] = [x for x in range(0,len(new_df))]
new_df

col = ["P_id","N_id","weight","cluster_id"]
df_weight = spark.createDataFrame(new_df, schema=col)
df_weight.show()

## import dataset 1 and 2 into df1 and df2


# df1 = ss.read.option("header",True)\
#         .option("inferSchema",True)\
#         .csv('Amazon.csv')
#
# df2 = ss.read.option("header",True)\
#         .option("inferSchema",True)\
#         .csv('GoogleProducts.csv')

from pyspark.sql.functions import monotonically_increasing_id

df1 = df1.withColumn("new_id", monotonically_increasing_id())
df2 = df2.withColumn("new_id", monotonically_increasing_id())

df1.show(5)
df2.show(5)



common_df = df1.join(df_weight,df1.new_id == df_weight.P_id,"inner")
common_N = df2.join(df_weight,df2.new_id == df_weight.N_id,"inner")


############################ union dataframe
import functools

def unionAll(dfs):
    return functools.reduce(lambda df1, df2: df1.union(df2.select(df1.columns)), dfs)


# unionAll
result3 = unionAll([common_df, common_N])
result3.show()

final = result3.toPandas()

final = final.drop(["P_id","N_id","weight"], axis=1)
final.head()

final_cluster = final.groupby(['cluster_id','id'])
final_cluster.first()

df = pd.concat(map(lambda x: x[1], final_cluster))

df = df.reset_index().drop(["index","id"],axis =1)

new_col = [x for x in range(0,len(df))]
df.insert(loc=0, column='id', value=new_col)
print(df.head(10))
print(df)

df1 = spark.createDataFrame(df)

df1.show(40)

df1.write.option('header',True).csv("hdfs://localhost:9000/ER_Project/stage/Amazon_Google_Examples/output",mode = 'overwrite')

print("File written successfully on HDFS .")

spark.read.csv("hdfs://localhost:9000/ER_Project/stage/Amazon_Google_Examples/output", header=True).show()


